import 'package:flutter_test/flutter_test.dart';
import 'package:project_messenger/core/util.dart';

void main() {
  test('normalizes Iranian mobile formats', () {
    expect(normalizeIranPhone('09123456789'), '+989123456789');
    expect(normalizeIranPhone('9123456789'), '+989123456789');
    expect(normalizeIranPhone('+98 912 345 6789'), '+989123456789');
    expect(normalizeIranPhone('۰۹۱۲۳۴۵۶۷۸۹'), '+989123456789');
    expect(normalizeIranPhone('0912345'), isNull);
    expect(normalizeIranPhone('02112345678'), isNull);
  });
}
