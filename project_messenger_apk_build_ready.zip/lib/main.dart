import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'auth/auth_service.dart';
import 'core/config.dart';
import 'data/repository.dart';
import 'sync/sync_service.dart';
import 'sync/transport.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = SettingsModel();
  await settings.load();
  final auth = AuthService();
  await auth.load();
  final repo = Repository();
  final Transport transport =
      AppConfig.devLoopback ? LoopbackTransport() : WsTransport();
  final sync = SyncService(repo, transport, auth);

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider<SettingsModel>.value(value: settings),
      ChangeNotifierProvider<AuthService>.value(value: auth),
      ChangeNotifierProvider<Repository>.value(value: repo),
      Provider<SyncService>.value(value: sync),
    ],
    child: const MessengerApp(),
  ));
}
