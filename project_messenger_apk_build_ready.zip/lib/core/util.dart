String normalizeDigits(String s) {
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final r in s.runes) {
    final ch = String.fromCharCode(r);
    var i = fa.indexOf(ch);
    if (i < 0) i = ar.indexOf(ch);
    b.write(i >= 0 ? i.toString() : ch);
  }
  return b.toString();
}

/// Returns +989XXXXXXXXX or null if the input is not a valid Iranian mobile.
String? normalizeIranPhone(String input) {
  var s = normalizeDigits(input).replaceAll(RegExp(r'[\s\-()]'), '');
  if (s.startsWith('+98')) {
    s = s.substring(3);
  } else if (s.startsWith('0098')) {
    s = s.substring(4);
  } else if (s.startsWith('98') && s.length == 12) {
    s = s.substring(2);
  } else if (s.startsWith('0')) {
    s = s.substring(1);
  }
  if (RegExp(r'^9\d{9}$').hasMatch(s)) return '+98$s';
  return null;
}
