/// Build-time configuration. Override with --dart-define, e.g.
/// flutter run --dart-define=DEV_LOOPBACK=false --dart-define=API_BASE=https://api.example.ir
class AppConfig {
  static const appName =
      String.fromEnvironment('APP_NAME', defaultValue: 'PROJECT MESSENGER');
  static const apiBase =
      String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:3000');
  static const wsUrl =
      String.fromEnvironment('WS_URL', defaultValue: 'ws://10.0.2.2:3000/ws');

  /// When true, no server is needed: login accepts any code and a fake
  /// transport acks and echoes messages. FOR DEVELOPMENT ONLY.
  static const devLoopback =
      bool.fromEnvironment('DEV_LOOPBACK', defaultValue: true);
}
