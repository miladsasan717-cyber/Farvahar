import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../auth/auth_service.dart';
import '../data/models.dart';
import '../data/repository.dart';
import 'transport.dart';

/// Sends the outbox when connected, reconnects with exponential backoff,
/// and applies acks/incoming messages to the local DB.
class SyncService {
  SyncService(this.repo, this.transport, this.auth);

  final Repository repo;
  final Transport transport;
  final AuthService auth;

  final ValueNotifier<bool> online = ValueNotifier(false);
  StreamSubscription? _sub;
  Timer? _retry;
  bool _flushing = false;
  bool _started = false;
  int _backoff = 2;

  Future<void> start() async {
    if (_started) return;
    _started = true;
    _sub = transport.events.listen(_onEvent);
    await _connect();
  }

  Future<void> stop() async {
    _started = false;
    _retry?.cancel();
    await _sub?.cancel();
    await transport.close();
    online.value = false;
  }

  Future<void> _connect() async {
    if (!_started || auth.token == null) return;
    try {
      await transport.connect(auth.token!);
      _backoff = 2;
      online.value = true;
      await flush();
    } catch (_) {
      online.value = false;
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    _retry?.cancel();
    _retry = Timer(Duration(seconds: _backoff), _connect);
    _backoff = min(_backoff * 2, 60);
  }

  Future<void> flush() async {
    if (_flushing || !transport.connected) return;
    _flushing = true;
    try {
      for (final m in await repo.outbox()) {
        await repo.setStatus(m.id, MsgStatus.sending);
        try {
          await transport.send({
            'type': 'msg',
            'id': m.id,
            'conversation_id': m.conversationId,
            'body': m.body,
            'created_at': m.createdAt,
            'client_seq': m.clientSeq,
          });
        } catch (_) {
          await repo.setStatus(m.id, MsgStatus.pending, force: true);
          break;
        }
      }
    } finally {
      _flushing = false;
    }
  }

  Future<void> _onEvent(Map<String, dynamic> f) async {
    switch (f['type']) {
      case 'ack':
        final s = {
          'sent': MsgStatus.sent,
          'delivered': MsgStatus.delivered,
          'read': MsgStatus.read,
        }[f['status']];
        if (s != null) await repo.setStatus(f['id'] as String, s);
        break;
      case 'msg':
        await repo.receive(f);
        break;
      case '_closed':
        online.value = false;
        await repo.resetSending();
        _scheduleReconnect();
        break;
    }
  }
}
