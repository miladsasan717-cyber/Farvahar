import 'dart:async';
import 'dart:convert';

import 'package:uuid/uuid.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../core/config.dart';

/// Wire format (JSON frames):
///  client -> server: {type:'msg', id, conversation_id, body, created_at, client_seq}
///  server -> client: {type:'ack', id, status:'sent'|'delivered'|'read'}
///  server -> client: {type:'msg', id, conversation_id, sender_id, body, created_at}
abstract class Transport {
  Stream<Map<String, dynamic>> get events;
  bool get connected;
  Future<void> connect(String token);
  Future<void> send(Map<String, dynamic> frame);
  Future<void> close();
}

class WsTransport implements Transport {
  WebSocketChannel? _ch;
  final _ctl = StreamController<Map<String, dynamic>>.broadcast();
  bool _connected = false;

  @override
  Stream<Map<String, dynamic>> get events => _ctl.stream;
  @override
  bool get connected => _connected;

  @override
  Future<void> connect(String token) async {
    final ch = WebSocketChannel.connect(Uri.parse(
        '${AppConfig.wsUrl}?token=${Uri.encodeQueryComponent(token)}'));
    await ch.ready;
    _ch = ch;
    _connected = true;
    ch.stream.listen(
      (d) {
        try {
          final m = jsonDecode(d as String);
          if (m is Map<String, dynamic>) _ctl.add(m);
        } catch (_) {}
      },
      onDone: _onClosed,
      onError: (_) => _onClosed(),
    );
  }

  void _onClosed() {
    if (!_connected) return;
    _connected = false;
    _ctl.add({'type': '_closed'});
  }

  @override
  Future<void> send(Map<String, dynamic> frame) async {
    if (!_connected || _ch == null) throw StateError('not connected');
    _ch!.sink.add(jsonEncode(frame));
  }

  @override
  Future<void> close() async {
    _connected = false;
    await _ch?.sink.close();
  }
}

/// Development-only stand-in for a server: acks, "delivers" and echoes.
class LoopbackTransport implements Transport {
  final _ctl = StreamController<Map<String, dynamic>>.broadcast();
  bool _connected = false;

  @override
  Stream<Map<String, dynamic>> get events => _ctl.stream;
  @override
  bool get connected => _connected;

  @override
  Future<void> connect(String token) async => _connected = true;

  @override
  Future<void> send(Map<String, dynamic> frame) async {
    if (!_connected) throw StateError('not connected');
    if (frame['type'] != 'msg') return;
    final id = frame['id'] as String;
    Timer(const Duration(milliseconds: 300),
        () => _ctl.add({'type': 'ack', 'id': id, 'status': 'sent'}));
    Timer(const Duration(milliseconds: 800),
        () => _ctl.add({'type': 'ack', 'id': id, 'status': 'delivered'}));
    Timer(const Duration(milliseconds: 1300),
        () => _ctl.add({'type': 'ack', 'id': id, 'status': 'read'}));
    Timer(const Duration(milliseconds: 1800), () {
      _ctl.add({
        'type': 'msg',
        'id': const Uuid().v4(),
        'conversation_id': frame['conversation_id'],
        'sender_id': 'peer',
        'body': 'echo: ${frame['body']}',
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
    });
  }

  @override
  Future<void> close() async => _connected = false;
}
