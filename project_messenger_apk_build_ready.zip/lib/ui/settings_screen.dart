import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app.dart';
import '../auth/auth_service.dart';
import '../core/strings.dart';
import '../sync/sync_service.dart';
import 'welcome_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const _colors = [0xFF2AABEE, 0xFF4CAF50, 0xFF9C27B0, 0xFFFF9800, 0xFFE91E63];

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsModel>();
    return Scaffold(
      appBar: AppBar(title: Text(L.of(context, 'settings'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(L.of(context, 'theme'), style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<ThemeMode>(
          segments: [
            ButtonSegment(value: ThemeMode.light, label: Text(L.of(context, 'light'))),
            ButtonSegment(value: ThemeMode.dark, label: Text(L.of(context, 'dark'))),
            ButtonSegment(value: ThemeMode.system, label: Text(L.of(context, 'system'))),
          ],
          selected: {s.themeMode},
          onSelectionChanged: (v) => s.setTheme(v.first),
        ),
        const SizedBox(height: 24),
        Text(L.of(context, 'accent'), style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Wrap(spacing: 12, children: [
          for (final c in _colors)
            GestureDetector(
              onTap: () => s.setAccent(c),
              child: CircleAvatar(
                backgroundColor: Color(c),
                child: s.accent == c ? const Icon(Icons.check, color: Colors.white) : null,
              ),
            ),
        ]),
        const SizedBox(height: 24),
        Text(L.of(context, 'font_size'), style: Theme.of(context).textTheme.titleMedium),
        Slider(
          value: s.fontScale,
          min: 0.85,
          max: 1.4,
          divisions: 11,
          onChanged: s.setFontScale,
        ),
        const SizedBox(height: 16),
        Text(L.of(context, 'language'), style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'fa', label: Text('فارسی')),
            ButtonSegment(value: 'en', label: Text('English')),
          ],
          selected: {s.lang},
          onSelectionChanged: (v) => s.setLang(v.first),
        ),
        const SizedBox(height: 32),
        OutlinedButton.icon(
          icon: const Icon(Icons.logout),
          label: Text(L.of(context, 'logout')),
          onPressed: () async {
            final nav = Navigator.of(context);
            await context.read<SyncService>().stop();
            if (!context.mounted) return;
            await context.read<AuthService>().logout();
            nav.pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const WelcomeScreen()), (_) => false);
          },
        ),
      ]),
    );
  }
}
