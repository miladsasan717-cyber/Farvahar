import 'package:flutter/material.dart';

import '../core/config.dart';
import '../core/strings.dart';
import 'register_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const Spacer(),
            Icon(Icons.send_rounded, size: 96, color: cs.primary),
            const SizedBox(height: 24),
            Text(L.of(context, 'welcome_title'),
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text(AppConfig.appName, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Text(L.of(context, 'welcome_sub'), textAlign: TextAlign.center),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const RegisterScreen())),
                child: Text(L.of(context, 'start')),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
