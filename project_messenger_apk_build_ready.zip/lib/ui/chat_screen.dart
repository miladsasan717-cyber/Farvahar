import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../auth/auth_service.dart';
import '../core/strings.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../sync/sync_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.conversation});
  final Conversation conversation;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<Repository>().markRead(widget.conversation.id);
    });
  }

  Future<void> _send() async {
    final text = _ctl.text;
    if (text.trim().isEmpty) return;
    _ctl.clear();
    final repo = context.read<Repository>();
    final sync = context.read<SyncService>();
    final me = context.read<AuthService>().userId ?? 'me';
    await repo.sendText(widget.conversation.id, me, text);
    await sync.flush();
  }

  IconData _icon(MsgStatus s) {
    switch (s) {
      case MsgStatus.pending:
        return Icons.schedule;
      case MsgStatus.sending:
        return Icons.arrow_upward;
      case MsgStatus.sent:
        return Icons.check;
      case MsgStatus.delivered:
      case MsgStatus.read:
        return Icons.done_all;
      case MsgStatus.failed:
        return Icons.error_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<Repository>();
    final me = context.read<AuthService>().userId ?? 'me';
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.conversation.title)),
      body: Column(children: [
        Expanded(
          child: FutureBuilder<List<Message>>(
            future: repo.messages(widget.conversation.id),
            builder: (context, snap) {
              final msgs = snap.data ?? const <Message>[];
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.all(8),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  final mine = m.senderId == me;
                  final time = DateFormat.Hm().format(DateTime.fromMillisecondsSinceEpoch(m.createdAt));
                  return Align(
                    alignment: mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 3),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                      decoration: BoxDecoration(
                        color: mine ? cs.primaryContainer : cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(m.body),
                        const SizedBox(height: 2),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(time, style: Theme.of(context).textTheme.labelSmall),
                          if (mine) ...[
                            const SizedBox(width: 4),
                            Icon(_icon(m.status),
                                size: 14,
                                color: m.status == MsgStatus.read
                                    ? cs.primary
                                    : m.status == MsgStatus.failed
                                        ? cs.error
                                        : null),
                          ],
                        ]),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _ctl,
                  minLines: 1,
                  maxLines: 5,
                  textInputAction: TextInputAction.newline,
                  decoration: InputDecoration(
                    hintText: L.of(context, 'type_message'),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
