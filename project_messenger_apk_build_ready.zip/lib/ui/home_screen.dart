import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../core/config.dart';
import '../core/strings.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../sync/sync_service.dart';
import 'chat_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SyncService>().start();
    });
  }

  Future<void> _newChat() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L.of(ctx, 'new_chat')),
        content: TextField(
            controller: c, autofocus: true, decoration: InputDecoration(labelText: L.of(ctx, 'name'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L.of(ctx, 'cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: Text(L.of(ctx, 'create'))),
        ],
      ),
    );
    if (name == null || name.isEmpty || !mounted) return;
    final conv = await context.read<Repository>().createConversation(name);
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(conversation: conv)));
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<Repository>();
    final sync = context.read<SyncService>();
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L.of(context, 'chats')),
          ValueListenableBuilder<bool>(
            valueListenable: sync.online,
            builder: (_, on, __) => Text(
              L.of(context, on ? 'online' : 'offline'),
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: _newChat, child: const Icon(Icons.edit)),
      body: Column(children: [
        if (AppConfig.devLoopback)
          Container(
            width: double.infinity,
            color: Theme.of(context).colorScheme.tertiaryContainer,
            padding: const EdgeInsets.all(6),
            child: Text(L.of(context, 'dev_note'), textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelSmall),
          ),
        Expanded(
          child: FutureBuilder<List<Conversation>>(
            future: repo.conversations(),
            builder: (context, snap) {
              final list = snap.data ?? const <Conversation>[];
              if (snap.connectionState == ConnectionState.done && list.isEmpty) {
                return Center(child: Text(L.of(context, 'no_chats')));
              }
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final c = list[i];
                  return ListTile(
                    leading: CircleAvatar(child: Text(c.title.isEmpty ? '?' : c.title.characters.first)),
                    title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(c.lastBody ?? '', maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(DateFormat.Hm().format(DateTime.fromMillisecondsSinceEpoch(c.lastAt)),
                          style: Theme.of(context).textTheme.labelSmall),
                      if (c.unread > 0)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary,
                              borderRadius: BorderRadius.circular(10)),
                          child: Text('${c.unread}',
                              style: TextStyle(
                                  color: Theme.of(context).colorScheme.onPrimary, fontSize: 11)),
                        ),
                    ]),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => ChatScreen(conversation: c))),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
