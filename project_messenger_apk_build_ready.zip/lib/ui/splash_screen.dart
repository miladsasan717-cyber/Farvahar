import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../auth/auth_service.dart';
import '../core/config.dart';
import '../data/db.dart';
import 'home_screen.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await AppDb.get();
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    final signedIn = context.read<AuthService>().signedIn;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => signedIn ? const HomeScreen() : const WelcomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.primary,
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.send_rounded, size: 72, color: cs.onPrimary),
          const SizedBox(height: 16),
          Text(AppConfig.appName,
              style: TextStyle(color: cs.onPrimary, fontSize: 22, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }
}
