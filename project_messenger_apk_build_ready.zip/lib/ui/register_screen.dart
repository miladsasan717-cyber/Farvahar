import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../auth/auth_service.dart';
import '../core/strings.dart';
import '../core/util.dart';
import 'home_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _phone = TextEditingController();
  final _code = TextEditingController();
  String? _normalized;
  String? _error;
  bool _busy = false;

  Future<void> _sendCode() async {
    final n = normalizeIranPhone(_phone.text);
    if (n == null) {
      setState(() => _error = L.of(context, 'invalid_phone'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await context.read<AuthService>().requestOtp(n);
      if (mounted) setState(() => _normalized = n);
    } catch (_) {
      if (mounted) setState(() => _error = L.of(context, 'error_generic'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verify() async {
    final code = normalizeDigits(_code.text.trim());
    if (code.length < 4) {
      setState(() => _error = L.of(context, 'invalid_code'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await context.read<AuthService>().verifyOtp(_normalized!, code);
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false);
    } catch (_) {
      if (mounted) setState(() => _error = L.of(context, 'invalid_code'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final step2 = _normalized != null;
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (!step2)
            TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                labelText: L.of(context, 'phone'),
                hintText: L.of(context, 'phone_hint'),
                prefixText: '+98  ',
                border: const OutlineInputBorder(),
              ),
            )
          else ...[
            Text(_normalized!, textDirection: TextDirection.ltr, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            TextField(
              controller: _code,
              keyboardType: TextInputType.number,
              textDirection: TextDirection.ltr,
              maxLength: 6,
              decoration: InputDecoration(
                labelText: L.of(context, 'code'),
                border: const OutlineInputBorder(),
              ),
            ),
          ],
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : (step2 ? _verify : _sendCode),
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : Text(L.of(context, step2 ? 'verify' : 'send_code')),
          ),
        ]),
      ),
    );
  }
}
