import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import 'db.dart';
import 'models.dart';

class Repository extends ChangeNotifier {
  final _uuid = const Uuid();

  Future<List<Conversation>> conversations() async {
    final db = await AppDb.get();
    final rows = await db.query('conversations', orderBy: 'last_at DESC');
    return rows.map(Conversation.fromMap).toList();
  }

  Future<List<Message>> messages(String cid) async {
    final db = await AppDb.get();
    final rows = await db.query('messages',
        where: 'conversation_id = ?',
        whereArgs: [cid],
        orderBy: 'created_at DESC, client_seq DESC',
        limit: 500);
    return rows.map(Message.fromMap).toList();
  }

  Future<Conversation> createConversation(String title) async {
    final db = await AppDb.get();
    final id = _uuid.v4();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert('conversations',
        {'id': id, 'title': title, 'last_at': now, 'unread': 0});
    notifyListeners();
    return Conversation(id: id, title: title, lastAt: now, unread: 0);
  }

  /// Stores the message locally as Pending. The sync service sends it.
  Future<void> sendText(String cid, String senderId, String text) async {
    final body = text.trim();
    if (body.isEmpty) return;
    final db = await AppDb.get();
    final seqRow = await db
        .rawQuery('SELECT COALESCE(MAX(client_seq),0)+1 AS n FROM messages');
    final seq = seqRow.first['n'] as int;
    final now = DateTime.now().millisecondsSinceEpoch;
    final m = Message(
      id: _uuid.v4(),
      conversationId: cid,
      senderId: senderId,
      body: body,
      createdAt: now,
      clientSeq: seq,
      status: MsgStatus.pending,
    );
    await db.transaction((txn) async {
      await txn.insert('messages', m.toMap());
      await txn.update('conversations', {'last_body': body, 'last_at': now},
          where: 'id = ?', whereArgs: [cid]);
    });
    notifyListeners();
  }

  /// Messages waiting to be sent, in the order they were written.
  Future<List<Message>> outbox() async {
    final db = await AppDb.get();
    final rows = await db.query('messages',
        where: 'status = ?',
        whereArgs: [MsgStatus.pending.index],
        orderBy: 'client_seq ASC');
    return rows.map(Message.fromMap).toList();
  }

  /// Status only moves forward unless [force] is set (used to retry).
  Future<void> setStatus(String id, MsgStatus s, {bool force = false}) async {
    final db = await AppDb.get();
    if (force) {
      await db.update('messages', {'status': s.index},
          where: 'id = ?', whereArgs: [id]);
    } else {
      await db.update('messages', {'status': s.index},
          where: 'id = ? AND status < ?', whereArgs: [id, s.index]);
    }
    notifyListeners();
  }

  /// After a dropped connection, anything "Sending" goes back to Pending.
  /// The server de-duplicates by message id, so a resend is safe.
  Future<void> resetSending() async {
    final db = await AppDb.get();
    await db.update('messages', {'status': MsgStatus.pending.index},
        where: 'status = ?', whereArgs: [MsgStatus.sending.index]);
    notifyListeners();
  }

  Future<void> receive(Map<String, dynamic> f) async {
    final db = await AppDb.get();
    final cid = f['conversation_id'] as String;
    final body = f['body'] as String;
    final at = (f['created_at'] as num?)?.toInt() ??
        DateTime.now().millisecondsSinceEpoch;
    final m = Message(
      id: f['id'] as String,
      conversationId: cid,
      senderId: f['sender_id'] as String? ?? 'peer',
      body: body,
      createdAt: at,
      clientSeq: (f['client_seq'] as num?)?.toInt() ?? 0,
      status: MsgStatus.delivered,
    );
    await db.transaction((txn) async {
      final ex = await txn.query('conversations',
          where: 'id = ?', whereArgs: [cid], limit: 1);
      if (ex.isEmpty) {
        await txn.insert('conversations', {
          'id': cid,
          'title': f['sender_name'] ?? cid,
          'last_at': 0,
          'unread': 0
        });
      }
      final n = await txn.insert('messages', m.toMap(),
          conflictAlgorithm: ConflictAlgorithm.ignore);
      if (n > 0) {
        await txn.rawUpdate(
            'UPDATE conversations SET last_body = ?, last_at = ?, unread = unread + 1 WHERE id = ?',
            [body, at, cid]);
      }
    });
    notifyListeners();
  }

  Future<void> markRead(String cid) async {
    final db = await AppDb.get();
    await db.update('conversations', {'unread': 0},
        where: 'id = ?', whereArgs: [cid]);
    notifyListeners();
  }
}
