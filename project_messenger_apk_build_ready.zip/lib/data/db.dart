import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Local database. NOTE: not yet encrypted; swap to sqflite_sqlcipher
/// (same API) before shipping to protect data at rest.
class AppDb {
  static Database? _db;

  static Future<Database> get() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'messenger.db');
    _db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE conversations(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            last_body TEXT,
            last_at INTEGER NOT NULL DEFAULT 0,
            unread INTEGER NOT NULL DEFAULT 0
          )''');
        await db.execute('''
          CREATE TABLE messages(
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL,
            sender_id TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            client_seq INTEGER NOT NULL,
            status INTEGER NOT NULL,
            FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
          )''');
        await db.execute(
            'CREATE INDEX idx_messages_conv_time ON messages(conversation_id, created_at)');
        await db.execute('CREATE INDEX idx_messages_status ON messages(status)');
      },
    );
    return _db!;
  }

  static Future<void> wipe() async {
    final db = await get();
    await db.delete('messages');
    await db.delete('conversations');
  }
}
