enum MsgStatus { pending, sending, sent, delivered, read, failed }

class Message {
  final String id;
  final String conversationId;
  final String senderId;
  final String body;
  final int createdAt;
  final int clientSeq;
  final MsgStatus status;

  const Message({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.body,
    required this.createdAt,
    required this.clientSeq,
    required this.status,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'conversation_id': conversationId,
        'sender_id': senderId,
        'body': body,
        'created_at': createdAt,
        'client_seq': clientSeq,
        'status': status.index,
      };

  factory Message.fromMap(Map<String, Object?> m) => Message(
        id: m['id'] as String,
        conversationId: m['conversation_id'] as String,
        senderId: m['sender_id'] as String,
        body: m['body'] as String,
        createdAt: m['created_at'] as int,
        clientSeq: m['client_seq'] as int,
        status: MsgStatus.values[m['status'] as int],
      );
}

class Conversation {
  final String id;
  final String title;
  final String? lastBody;
  final int lastAt;
  final int unread;

  const Conversation({
    required this.id,
    required this.title,
    this.lastBody,
    required this.lastAt,
    required this.unread,
  });

  factory Conversation.fromMap(Map<String, Object?> m) => Conversation(
        id: m['id'] as String,
        title: m['title'] as String,
        lastBody: m['last_body'] as String?,
        lastAt: m['last_at'] as int,
        unread: m['unread'] as int,
      );
}
