import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/config.dart';
import 'ui/splash_screen.dart';

class SettingsModel extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  int accent = 0xFF2AABEE;
  double fontScale = 1.0;
  String lang = 'fa';

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values[p.getInt('theme') ?? 0];
    accent = p.getInt('accent') ?? accent;
    fontScale = p.getDouble('font_scale') ?? 1.0;
    lang = p.getString('lang') ?? 'fa';
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme', themeMode.index);
    await p.setInt('accent', accent);
    await p.setDouble('font_scale', fontScale);
    await p.setString('lang', lang);
  }

  void setTheme(ThemeMode m) {
    themeMode = m;
    _save();
    notifyListeners();
  }

  void setAccent(int c) {
    accent = c;
    _save();
    notifyListeners();
  }

  void setFontScale(double v) {
    fontScale = v;
    _save();
    notifyListeners();
  }

  void setLang(String l) {
    lang = l;
    _save();
    notifyListeners();
  }
}

class MessengerApp extends StatelessWidget {
  const MessengerApp({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsModel>();
    ThemeData theme(Brightness b) => ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: Color(s.accent), brightness: b),
        );
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: theme(Brightness.light),
      darkTheme: theme(Brightness.dark),
      themeMode: s.themeMode,
      locale: Locale(s.lang),
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(s.fontScale)),
        child: child!,
      ),
      home: const SplashScreen(),
    );
  }
}
