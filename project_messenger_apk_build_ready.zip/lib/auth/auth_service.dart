import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../core/config.dart';
import '../data/db.dart';

class AuthService extends ChangeNotifier {
  final _storage = const FlutterSecureStorage();
  String? token;
  String? userId;
  String? phone;

  bool get signedIn => token != null;

  Future<void> load() async {
    token = await _storage.read(key: 'token');
    userId = await _storage.read(key: 'user_id');
    phone = await _storage.read(key: 'phone');
  }

  Future<void> requestOtp(String phone) async {
    if (AppConfig.devLoopback) return;
    final r = await http
        .post(Uri.parse('${AppConfig.apiBase}/auth/request-otp'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'phone': phone}))
        .timeout(const Duration(seconds: 15));
    if (r.statusCode != 200 && r.statusCode != 201) {
      throw Exception('request-otp failed: ${r.statusCode}');
    }
  }

  Future<void> verifyOtp(String phone, String code) async {
    if (AppConfig.devLoopback) {
      await _save('dev-token', 'me', phone);
      return;
    }
    final r = await http
        .post(Uri.parse('${AppConfig.apiBase}/auth/verify'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'phone': phone, 'code': code}))
        .timeout(const Duration(seconds: 15));
    if (r.statusCode != 200 && r.statusCode != 201) {
      throw Exception('verify failed: ${r.statusCode}');
    }
    final j = jsonDecode(r.body) as Map<String, dynamic>;
    await _save(j['token'] as String, j['user_id'] as String, phone);
  }

  Future<void> _save(String t, String u, String ph) async {
    token = t;
    userId = u;
    phone = ph;
    await _storage.write(key: 'token', value: t);
    await _storage.write(key: 'user_id', value: u);
    await _storage.write(key: 'phone', value: ph);
    notifyListeners();
  }

  Future<void> logout() async {
    await _storage.deleteAll();
    await AppDb.wipe();
    token = null;
    userId = null;
    phone = null;
    notifyListeners();
  }
}
