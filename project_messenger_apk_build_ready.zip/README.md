# PROJECT MESSENGER — Flutter client (v0.1)

نیازمندی: Flutter 3.22 یا جدیدتر.

## اجرا
```bash
flutter create --org ir.example --project-name project_messenger .
# فایل‌های lib/ pubspec.yaml test/ این پوشه جایگزین نسخه‌ی تولیدشده می‌شوند
flutter pub get
flutter test
flutter run            # حالت توسعه بدون سرور (DEV_LOOPBACK=true)
```

## اتصال به سرور واقعی
```bash
flutter run --dart-define=DEV_LOOPBACK=false \
  --dart-define=API_BASE=https://api.example.ir \
  --dart-define=WS_URL=wss://api.example.ir/ws
```
برای تست با HTTP ساده روی اندروید، در `android/app/src/main/AndroidManifest.xml`
به تگ `<application>` اضافه کنید: `android:usesCleartextTraffic="true"` (فقط توسعه).

## قرارداد API (که بک‌اند باید پیاده کند)
- `POST /auth/request-otp` {phone}
- `POST /auth/verify` {phone, code} → {token, user_id}
- `WS /ws?token=...` با فریم‌های JSON (در `lib/sync/transport.dart` مستند شده)

## چه چیزی کار می‌کند
ثبت‌نام با شماره +98 و کد، SQLite محلی، صف پیام‌های ارسال‌نشده، ارسال خودکار پس از اتصال،
بازاتصال با backoff، جلوگیری از ارسال تکراری با شناسه یکتا، وضعیت‌های Pending→Read،
تم روشن/تیره/سیستم، رنگ اصلی، اندازه نوشته، فارسی/انگلیسی با RTL.

## هنوز پیاده نشده
بک‌اند، E2EE، گروه/کانال، فایل و صوت، تماس، ارتباط آفلاین (Nearby/BLE/LAN)،
اعلان، رمزگذاری SQLite (SQLCipher).


## ساخت APK با GitHub Actions
این بسته پوشه Android تولیدشده را ندارد؛ فایل workflow در
`.github/workflows/build-apk.yml` آن را در محیط GitHub Actions ایجاد می‌کند،
وابستگی‌ها و تست‌ها را اجرا می‌کند و APK نسخه release می‌سازد.

1. محتویات این پوشه را در ریشه یک مخزن GitHub قرار دهید.
2. مخزن را با نام دلخواه روی GitHub ایجاد و فایل‌ها را Push کنید.
3. از زبانه Actions، اجرای **Build Android APK** را باز کنید.
4. پس از موفقیت، از بخش Artifacts فایل `project-messenger-release-apk` را دانلود کنید.

نکته: برنامه در تنظیم پیش‌فرض از `DEV_LOOPBACK=true` استفاده می‌کند؛ بنابراین
برای آزمایش محلی به بک‌اند نیاز ندارد و پیام‌ها شبیه‌سازی می‌شوند. برای پیام‌رسانی
واقعی باید بک‌اند مطابق قرارداد API بالا پیاده‌سازی و آدرس‌های API/WS تنظیم شوند.
